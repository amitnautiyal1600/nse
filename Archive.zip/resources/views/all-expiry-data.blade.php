<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>NSE | All DATA</title> 

        <!-- Styles -->  
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
 
        <link href="//cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
        <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.css"/>
        <!-- Styles End-->  

        <!-- Scripts --> 
        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>
        <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script> 
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
        <!-- Scripts End--> 
        <style type="text/css">
            .index-cell{
                background: darkred !important; 
                color: white !important; 

            }
            .body {
                font-size: 13px;
                font-family: sans-serif;
            }
            .dynamic_data_red {
                font-weight: 900;
                color: darkred;
            }
            .dynamic_data_green {
                font-weight: 900;
                color: green;
            }
            .ce-itm, .pe-itm {
                background: #faf3cd !important;
            }
            .row_selected {
                /*background: purple !important;*/
                border-bottom: 20px solid darkred;
                font-weight: 900;
                color: darkred;
            }
        </style> 
 
    </head>
    <body class="body">
        <main>
            <header class="p-3 text-bg-dark">
                <div class="container">
                  <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
                    <a href="/" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
                      <svg class="bi me-2" width="40" height="32" role="img" aria-label="Bootstrap"><use xlink:href="#bootstrap"></use></svg>
                    </a>

                    <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                      <li><a href="{{route('home')}}" class="nav-link px-2 text-secondary">Selected Range</a></li>
                      <li><a href="{{route('allData')}}" class="nav-link px-2 text-white">All Data</a></li>
                      <li><a href="{{route('oldData')}}" class="nav-link px-2 text-white">Saved Data</a></li>
                      <li><a href="{{route('charts')}}" class="nav-link px-2 text-white">Charts</a></li> 
                    </ul>

                    <form class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3" role="search">
                      <input type="search" class="form-control form-control-dark text-bg-dark" placeholder="Search..." aria-label="Search">
                    </form>

                    <div class="text-end">
                      <button type="button" class="btn btn-outline-light me-2 save_nse_data">
                            <i class="fa fa-floppy-o"></i> Save Data
                      </button>
                      <button type="button" class="btn btn-warning refresh_nse_data">
                          <i class="fa fa-refresh"></i> Refresh
                      </button>
                    </div>
                  </div>
                </div>
          </header>
      </main>
        <div class="container-fluid">

            <div class="row p-2" style="background:#faf3cd">
                <div class="col-md-4"> 
                    <span> Nifty Index <span class="dynamic_data_red nifty_index_value">0</span></span>
                </div>
                <div class="col-md-4"> 
                    <span> Expriy Date <span class="dynamic_data_red nifty_expiry_date">0</span></span>
                </div>  
                <div class="col-md-4"> 
                    <span>Last Updated : <span class="dynamic_data_red" id="datetime"></span></span>
                </div>  
            </div>

            <div class="row">
                <div class="col-md-4"> 
                    <table class="table table-sm table-bordered display compact stripe">
                        <tr>
                            <td><strong>Title</strong></td>
                            <td><strong>Value</strong></td>
                            <td><strong>Strike Price</strong></td>
                        <tr>
                        <tr>
                            <td>Max CE OI</td>
                            <td><span class="dynamic_data_green max_ce_oi">0</span></td>
                            <td><span class="dynamic_data_green max_ce_oi_strike">0</span></td>
                        <tr>
                        <tr>
                            <td>Max CE_OICHANGE</td>
                            <td><span class="dynamic_data_green max_ce_oichange">0</span></td>
                            <td><span class="dynamic_data_green max_ce_oichange_strike">0</span></td>
                        <tr>
                        <tr>
                            <td>Max PE OI</td>
                            <td><span class="dynamic_data_red max_pe_oi">0</span></td>
                            <td><span class="dynamic_data_red max_pe_oi_strike">0</span></td>
                        <tr>
                        <tr>
                            <td>Max PE_OICHANGE</td>
                            <td><span class="dynamic_data_red max_pe_oichange">0</span></td>
                            <td><span class="dynamic_data_red max_pe_oichange_strike">0</span></td>
                        <tr>

                    </table>
                </div> 

                <div class="col-md-4"> 
                    <table class="table table-sm table-bordered display compact stripe">
                        <tr>
                            <td>CE OI</td>
                            <td><span class="dynamic_data_green">0</span></td>
                            <td>PE OI</td>
                            <td><span class="dynamic_data_red">0</span></td>
                            <td>INTRADAY</td>
                            <td>POSITIONAL</td>
                        <tr>
                        <tr>
                            <td>CE OI CHANGE</td>
                            <td><span class="dynamic_data_green">0</span></td>
                            <td>PE OI CHANGE</td>
                            <td><span class="dynamic_data_red">0</span></td>
                            <td><span class="dynamic_data_red">FALSE</span></td>
                            <td><span class="dynamic_data_red">FALSE</span></td>
                        <tr>
                        <tr>
                            <td>CE VOLUME</td>
                            <td><span class="dynamic_data_green">0</span></td>
                            <td>PE VOLUME</td>
                            <td><span class="dynamic_data_red">0</span></td>
                        <tr>  
                    </table>
                </div> 

                <div class="col-md-4"> 
                    <table class="table table-sm table-bordered display compact stripe">
                        <tr>
                            <td>Total CE OI</td><td><span class="dynamic_data_green total_put_oi">0</span></td> 
                            <td>Total CE VOL</td><td><span class="dynamic_data_green total_put_volume">0</span></td> 
                        <tr>
                        <tr>
                            <td>Total PE OI</td><td><span class="dynamic_data_red total_call_oi">0</span></td> 
                            <td>Total PE VOL</td><td><span class="dynamic_data_red total_call_volume">0</span></td>  
                        <tr> 
                        <tr> 
                            <td>Total PCR OI</td><td><span class="dynamic_data_red total_pcr_oi">0</span></td> 
                            <td>Total PCR VOL</td><td><span class="dynamic_data_red total_pcr_volume">0</span></td>      
                        <tr> 
                    </table>
                </div> 
            </div>

            <!-- 
                PCR OI if > 1.7 can  BIG crash
                PCR OI if < 0.8 can 

             -->

            <div class="row">
                <div class="col"> 
                    <table id="nse_data_table" class="table table-sm table-bordered display compact stripe">
                        <thead>
                            <tr>
                                <th colspan="10" style="background: #0cb20c;text-align: center;">Call</th>
                                <th colspan="" style="background: darkred; color: white;text-align: center;">NIFTY</th>
                                <th colspan="10" style="background: #f95252;text-align: center;">Put</th> 
                                <th colspan="3" style="background: darkred;color: white;text-align: center;">Calculations</th> 
                            </tr>
                            <tr style="background: yellow;">
                               <th title="Open Interest in contracts">OI</th>
                               <th title="Change in Open Interest (Contracts)">Chng In OI</th>
                               <th title="Volume in Contracts">Volume</th>
                               <th title="Implied Volatility">IV</th>
                               <th title="Last Traded Price">LTP</th>
                               <th title="Change w.r.t to Previous Close">Chng</th>
                               <th title="Best Bid/Buy Qty">BidQty</th>
                               <th title="Best Bid/Buy Price">Bid Price</th>
                               <th title="Best Ask/Sell Price">Ask Price</th>
                               <th title="Best Ask/Sell Qty">Ask ty</th>
                               <th>Strike Price</th>
                               <th title="Best Bid/Buy Qty">Bid Qty</th>
                               <th title="Best Bid/Buy Price">Bid Price</th>
                               <th title="Best Ask/Sell Price">Ask Price</th>
                               <th title="Best Ask/Sell Qty">Ask Qty</th>
                               <th title="Change w.r.t to Previous Close">Chng</th>
                               <th title="Last Traded Price">LTP</th>
                               <th title="Implied Volatility">IV</th>
                               <th title="Volume in Contracts">Volume</th>
                               <th title="Change in Open Interest (Contracts)">Chng In OI</th>
                               <th title="Open Interest in contracts">OI</th>
                               <th title="calculation PCR">PCR</th> 
                            </tr>
                        </thead>
                        <tbody> 
                        </tbody>
                        <tfoot>
                            <th class="dynamic_data_green selected_put_oi_sum">0</th>
                            <th colspan=""></th> 
                            <th class="dynamic_data_green selected_put_vol_sum">0</th> 
                            <th colspan="15"></th>  
                            <th class="dynamic_data_red selected_call_vol_sum">0</th>
                            <th colspan=""></th> 
                            <th class="dynamic_data_red selected_call_oi_sum">0</th> 
                            <th class="dynamic_data_red selected_pcr_oi">0</th>  
                        </tfoot>
                    </table> 
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <canvas id="oiChart" style="width:100%;"></canvas>
                </div>
                <div class="col-md-12">
                    <canvas id="oiBarChart" style="width:100%;"></canvas>
                </div>
            </div>

        </div>
    </body>
    <script type="text/javascript"> 
        var oiChartObj;
        var oiBarChartObj;
        $( document ).ready(function() {

            toastr.options.positionClass = 'toast-bottom-left';

            $('#nse_data_table').dataTable({
                paging: true,
                pageLength: 100, 
                bPaginate: true,
                bInfo: true,
                ordering: false, 
                bFilter: true,
                bLengthChange: true,
                searching: true, 
                bDestroy: true, 
            }); 

            get_nse_data();

            setInterval(function() {
                get_nse_data();
            }, 60 * 3 * 1000); // 60 * 1000 milsec   // in every 3minutes

            setInterval(function() {
                save_nse_data();
            }, 60 * 60 * 1000); // 60 * 1000 milsec. // in every 1 hour

            $(document).on('click', '.refresh_nse_data', function(e){
                e.preventDefault(); 
                get_nse_data(); 
            });
            $(document).on('click', '.save_nse_data', function(e){
                e.preventDefault();
                save_nse_data(); 
            });

        });

        function save_nse_data() {
            var ajaxUrl = "save-nse-data"; 
            var index = 0;
            $.ajax({
                type: "GET",
                url: ajaxUrl,
                timeout: 40000, 
                dataType: 'json',
                beforeSend: function(response)
                {
                    //$('#pageloading').show();
                },
                success: function(response)
                { 
                    toastr.success('NSE data saved successfully!!'); 
                },
                error: function(response) {
                    toastr.error('Error In saving NSE data.<br/> TRY AGAIN!'); 
                },
                complete: function(response)
                {   
                    //$('#pageloading').hide();  
                }
            }); //Ajax End
        }

        function get_nse_data() {

            var today = new Date(); 
            $('#datetime').html( today.getHours() + ':' + today.getMinutes() + ' : ' + today.toDateString());

            var ajaxUrl = "get-all-nse-data"; 
            var index = 0;
            $.ajax({
                type: "GET",
                url: ajaxUrl,
                timeout: 40000, 
                dataType: 'json',
                beforeSend: function(response)
                {
                    //$('#pageloading').show();
                },
                success: function(response)
                {   
                    toastr.success('NSE data refreshed successfully!!'); 

                    $('.max_ce_oi').html(response.max_ce_oi);
                    $('.max_ce_oi_strike').html(response.max_ce_oi_strike);
                    $('.max_ce_oichange').html(response.max_ce_oichange);
                    $('.max_ce_oichange_strike').html(response.max_ce_oichange_strike);
                    $('.max_pe_oi').html(response.max_pe_oi);
                    $('.max_pe_oi_strike').html(response.max_pe_oi_strike);
                    $('.max_pe_oichange').html(response.max_pe_oichange);
                    $('.max_pe_oichange_strike').html(response.max_pe_oichange_strike);

                    $('.selected_put_oi_sum').html(response.selected_put_oi_sum);
                    $('.selected_put_vol_sum').html(response.selected_put_vol_sum);
                    $('.selected_call_vol_sum').html(response.selected_call_vol_sum);
                    $('.selected_call_oi_sum').html(response.selected_call_oi_sum);  
                    $('.selected_pcr_oi').html(response.selected_pcr_oi.toFixed(2));  


                    $('.total_call_oi').html(response.total_call_oi);
                    $('.total_call_volume').html(response.total_call_volume);
                    $('.total_put_oi').html(response.total_put_oi);
                    $('.total_put_volume').html(response.total_put_volume); 

                    $('.total_pcr_oi').html(response.total_pcr_oi.toFixed(2));
                    $('.total_pcr_volume').html(response.total_pcr_volume.toFixed(2));

                    if(oiChartObj != undefined)  oiChartObj.destroy();
                    oiChartObj = new Chart("oiChart", {
                      type: "line",
                      data: {
                        labels: response.chartdata.strike,
                        datasets: [{
                          data: response.chartdata.ceoi,
                          label: "Call Open Interest",
                          borderColor: "#0cb20c",
                          fill: true,
                          backgroundColor: '#faf3cd73',
                        },{
                          data: response.chartdata.peoi,
                          label: "Put Open Interest",
                          borderColor: "#f95252",
                          fill: true,
                          backgroundColor: '#faf3cd73',
                        }]
                      },
                      options: {
                            legend: {
                              display: true,
                              position: 'top', 
                              labels: {
                                fontColor: "darkred",
                              }
                            },
                            title: {
                               display: true,
                               text: "Open Interest",
                               fontColor: "darkred",
                              },
                        }
                    }); // end chart oi

                    if(oiBarChartObj != undefined)  oiBarChartObj.destroy();
                    var xValues = response.chartdata.strike;
                    var ceValues = response.chartdata.cechangeoi;
                    var peValues = response.chartdata.pechangeoi; 

                    oiBarChartObj =new Chart("oiBarChart", {
                      type: "bar",
                      data: {
                        labels: xValues,
                        datasets: [{
                          backgroundColor: '#0cb20c',
                          label: "Call Change In Open Interest",
                          data: ceValues
                        },
                        {
                          backgroundColor: '#f95252',
                          label: "Put Change In Open Interest",
                          data: peValues
                        }]
                      },
                      options: {
                        legend: {
                          display: true,
                          position: 'top', 
                          labels: {
                            fontColor: "darkred",
                          }
                        },
                        title: {
                          display: true,
                          text: "Change In Open Interest",
                          fontColor: "darkred",
                        }
                      }
                    });

                    response = response.tabledata;

                    $('.nifty_index_value').html(response[0].CE.underlyingValue);
                    $('.nifty_expiry_date').html(response[0].expiryDate);

                    $('#nse_data_table')
                        .on( 'draw.dt',  function () {
                            $("#nse_data_table tbody tr").on('click',function(event) {
                                $("#nse_data_table tbody tr").removeClass('row_selected');        
                                $(this).addClass('row_selected');
                            });
                            //$("#nse_data_table").unhighlight().highlight($('#searchme').val());
                        })
                        .dataTable({
                        paging: true,
                        pageLength: 100, 
                        bPaginate: true,
                        bInfo: true,
                        ordering: false, 
                        bFilter: true,
                        bLengthChange: true,
                        searching: true,
                        data: response, 
                        bDestroy: true, 
                        createdRow: (row, data, dataIndex, cells) => {
                            var strikePrice= data.strikePrice;   
                            if (strikePrice  > data.CE.underlyingValue && index == 0) {
                                index = data.CE.underlyingValue; 
                                $(row).find('td:eq(10)').addClass('index-cell');
                            }
                            if (strikePrice  < data.CE.underlyingValue) { 
                                $(row).find('td:eq(0)').addClass('ce-itm');
                                $(row).find('td:eq(1)').addClass('ce-itm');
                                $(row).find('td:eq(2)').addClass('ce-itm');
                                $(row).find('td:eq(3)').addClass('ce-itm');
                                $(row).find('td:eq(4)').addClass('ce-itm');
                                $(row).find('td:eq(5)').addClass('ce-itm');
                                $(row).find('td:eq(6)').addClass('ce-itm');
                                $(row).find('td:eq(7)').addClass('ce-itm');
                                $(row).find('td:eq(8)').addClass('ce-itm');
                                $(row).find('td:eq(9)').addClass('ce-itm'); 
                            }
                            if (strikePrice  > data.CE.underlyingValue) { 
                                $(row).find('td:eq(11)').addClass('pe-itm');
                                $(row).find('td:eq(12)').addClass('pe-itm');
                                $(row).find('td:eq(13)').addClass('pe-itm');
                                $(row).find('td:eq(14)').addClass('pe-itm');
                                $(row).find('td:eq(15)').addClass('pe-itm');
                                $(row).find('td:eq(16)').addClass('pe-itm');
                                $(row).find('td:eq(17)').addClass('pe-itm');
                                $(row).find('td:eq(18)').addClass('pe-itm');
                                $(row).find('td:eq(19)').addClass('pe-itm');
                                $(row).find('td:eq(20)').addClass('pe-itm');
                            }


                            $(cells[10]).css('background-color', '#a7dda7')
                            $(cells[21]).css('background-color', '#a7dda7')
                            $(cells[22]).css('background-color', '#a7dda7')
                            $(cells[23]).css('background-color', '#a7dda7')
                        },
                        aoColumns: [    
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var openInterest = data.CE.openInterest; 
                                    return openInterest;
                                }
                            },  
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var changeinOpenInterest = data.CE.changeinOpenInterest; 
                                    return changeinOpenInterest;
                                }
                            },  
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var totalTradedVolume = data.CE.totalTradedVolume; 
                                    return totalTradedVolume;
                                }
                            },  
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var impliedVolatility = data.CE.impliedVolatility; 
                                    return impliedVolatility;
                                }
                            },  
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var lastPrice = data.CE.lastPrice; 
                                    var html = "<span class='text-primary'>"+lastPrice+"</span>";
                                    return html;
                                }
                            },  
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var change = data.CE.change.toFixed(2); 
                                    if(change > 1)
                                        var html = "<span class='text-success'>"+change+"</span>";
                                    else 
                                        var html = "<span class='text-danger'>"+change+"</span>"; 
                                    return html;
                                }
                            },  
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var bidQty = data.CE.bidQty; 
                                    return bidQty;
                                }
                            },  
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var bidprice = data.CE.bidprice; 
                                    return bidprice;
                                }
                            },  
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var askPrice = data.CE.askPrice; 
                                    return askPrice;
                                }
                            },  
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var askQty = data.CE.askQty; 
                                    return askQty;
                                }
                            },  
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var strikePrice = data.strikePrice; 
                                    var html = '<span class="">'+strikePrice+'</span>';
                                    return html;
                                }
                            },  
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var bidQty = data.PE.bidQty; 
                                    return bidQty;
                                }
                            },  
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var bidprice = data.PE.bidprice; 
                                    return bidprice;
                                }
                            },  
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var askPrice = data.PE.askPrice; 
                                    return askPrice;
                                }
                            },  
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var askQty = data.PE.askQty; 
                                    return askQty;
                                }
                            },   
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var change = data.PE.change.toFixed(2); 
                                    if(change > 1)
                                        var html = "<span class='text-success'>"+change+"</span>";
                                    else 
                                        var html = "<span class='text-danger'>"+change+"</span>"; 
                                    return html;
                                }
                            }, 
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var lastPrice = data.PE.lastPrice; 
                                    var html = "<span class='text-primary'>"+lastPrice+"</span>";
                                    return html;
                                }
                            },  
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var impliedVolatility = data.PE.impliedVolatility; 
                                    return impliedVolatility;
                                }
                            },  
                             { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var totalTradedVolume = data.PE.totalTradedVolume; 
                                    return totalTradedVolume;
                                }
                            }, 
                           { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var changeinOpenInterest = data.PE.changeinOpenInterest; 
                                    return changeinOpenInterest;
                                }
                            },  
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var openInterest = data.PE.openInterest; 
                                    return openInterest;
                                }
                            },     
                            { "defaultContent": '-', 'data': "custom_function",
                                "render": function (custom_function, row, data) { 
                                    var CallopenInterest = data.CE.openInterest; 
                                    var PutopenInterest = data.PE.openInterest; 
                                    var pcr = CallopenInterest/PutopenInterest;
                                    pcr= pcr.toFixed(3);
                                    if(pcr < 5)
                                        var html = "<span class='text-black'>"+pcr+"</span>";
                                    else 
                                        var html = "<span class='text-black'>"+pcr+"</span>"; 
                                    return html;
                                }
                            },    
                               
                        ], 
                    });  
                     
                },
                error: function(response) {
                  toastr.error('Nse API not working <br/> TRY AGAIN');   
                },
                complete: function(response)
                {   
                    //$('#pageloading').hide();  
                }
            }); //Ajax End 

        }  
    </script>
</html>
